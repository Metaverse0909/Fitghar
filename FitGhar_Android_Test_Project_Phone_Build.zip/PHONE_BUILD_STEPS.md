# FitGhar APK, phone-only build

No Android Studio is needed on the phone.

1. Create/sign in to a GitHub account.
2. Create a new repository, for example `fitghar-android-test`.
3. Upload the complete contents of this ZIP to the repository. Keep the `.github/workflows/build-apk.yml` file.
4. Open the repository's `Actions` tab.
5. Select `Build FitGhar Test APK`.
6. Tap `Run workflow`.
7. Wait for the workflow to finish with a green check.
8. Open the completed workflow run.
9. Open `Artifacts`.
10. Download `FitGhar-Test-APK`.
11. Extract the ZIP on the phone.
12. Install `app-debug.apk`.

The workflow uses Java 17 and Gradle 8.13. Android Gradle Plugin 8.13 is compatible with Gradle 8.13 and API 36.

This is a DEBUG APK for testing, not the Play Store release build.
