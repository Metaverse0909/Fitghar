plugins {
    id("com.android.application")
}

android {
    namespace = "com.fitghar.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.fitghar.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}
