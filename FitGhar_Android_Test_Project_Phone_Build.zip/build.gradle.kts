plugins {
    id("com.android.application") version "8.13.1" apply false
}
