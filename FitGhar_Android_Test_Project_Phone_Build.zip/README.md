# FitGhar Android Test Project

This project wraps the current FitGhar single-file HTML in a native Android WebView.

Target API: 36
Min API: 23
Application ID: com.fitghar.app

Included:
- Current FitGhar HTML
- 1024x1024 app icon
- 1080x1920 splash artwork
- 3-second splash animation GIF for reference
- Android WebView wrapper
- Offline asset loading
- External affiliate links open outside the WebView
- DOM storage/localStorage
- Vibration permission

Build with Android Studio / Gradle:
./gradlew assembleDebug

APK:
app/build/outputs/apk/debug/app-debug.apk
